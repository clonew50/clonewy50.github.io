# delta-web
Bypass delta key executor
